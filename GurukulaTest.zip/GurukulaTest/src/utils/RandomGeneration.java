package utils;

import java.util.Random;

public class RandomGeneration {
	public static String generateRandomString(int length){
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int N = alphabet.length();

		Random r = new Random();
		String randomStr = "";
		for(int i=0;i<length;i++){
			randomStr = randomStr + alphabet.charAt(r.nextInt(N));
		}
		
		return randomStr;
	}
	
	public static int generateRandomNumber(int length){
		int max_num=1;
		for(int i=0;i<length;i++){
			max_num=max_num*10;
		}
		int randomNumber = new Random().nextInt(max_num);
		randomNumber = (randomNumber<max_num/10)?randomNumber+max_num:randomNumber;
		
		return randomNumber;
	}
}
