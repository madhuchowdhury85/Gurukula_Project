package utils;

public class XpathUtil {
	public static String getNavigationXpath(String menuOrSubmenu){
		return "//*[@id='navbar-collapse']//span[text()='"+menuOrSubmenu+"']";
	}
}
