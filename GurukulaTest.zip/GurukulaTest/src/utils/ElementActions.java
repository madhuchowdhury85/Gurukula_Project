package utils;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class ElementActions {
	protected WebDriver driver;
	protected Actions actions;
	protected WebDriverWait wait;
	protected JavascriptExecutor js;
	
	public enum DropDownType{
		BY_INDEX, BY_VALUE, BY_VISIBLE_TEXT;
	}
	
	protected ElementActions(WebDriver driver){
		this.driver = driver;
		actions = new Actions(driver);
		wait = new WebDriverWait(driver,10);
		js = (JavascriptExecutor)driver;
	}
	
	protected void clickOn(By locator){
		clickOn(locator, false);
	}
	
	protected void clickOn(By locator, boolean isScrollIntoView){
		wait.until(ExpectedConditions.elementToBeClickable(locator));
		if(isScrollIntoView)
			js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(locator));
		driver.findElement(locator).click();
	}
	
	protected void jsClick(By locator){
		wait.until(ExpectedConditions.elementToBeClickable(locator));
		js.executeScript("arguments[0].click();", driver.findElement(locator));
	}
	
	protected void mouseHover(By locator){
		actions.moveToElement(driver.findElement(locator)).perform();
	}
	
	protected void enterText(By locator, String text){
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		driver.findElement(locator).clear();
		driver.findElement(locator).sendKeys(text+Keys.TAB);
		waitForPageToBeLoaded();
	}
	
	protected String getAttribute(By locator, String attribute){
		return driver.findElement(locator).getAttribute(attribute);
	}
	
	protected void clearBox(By locator){
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		driver.findElement(locator).clear();
	}
	
	protected boolean verifyElement(By locator){
		boolean isFound = true;
		try{
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			driver.findElement(locator);
		}catch(Exception e){
			isFound = false;
		}
		return isFound;
	}
	
	protected boolean verifyElement(By locator, int seconds){
		boolean isFound = true;
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		try{
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			driver.findElement(locator);
		}catch(Exception e){
			isFound = false;
		}
		return isFound;
	}
	
	
	protected boolean checkForEnableElement(By locator){
		boolean isEnable = false;
		try{
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			WebElement ele = driver.findElement(locator);
			if(ele.isEnabled())
				isEnable = true;
		}catch(Exception e){
			
		}
		return isEnable;
	}
	
	protected boolean checkForVisibilityElement(By locator){
		boolean isDisplayed = false;
		try{
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			WebElement ele = driver.findElement(locator);
			if(ele.isDisplayed())
				isDisplayed = true;
		}catch(Exception e){
			
		}
		return isDisplayed;
	}
	
	protected List<WebElement> getElements(By locator){
		return driver.findElements(locator);
	}
	
	protected String getText(By locator){
		return getText(driver.findElement(locator));
	}
	
	protected String getText(WebElement element){
		return element.getText();
	}
	
	protected List<String> getMultipleText(By locator){
		List<WebElement> elements = driver.findElements(locator);
		List<String> textList = new ArrayList<String>();
		for(WebElement element: elements){
			textList.add(element.getText());
		}
		return textList;
	}
	
	protected void openURL(String URL){
		driver.get(URL);
	}
	
	protected void waitForPageToBeLoaded(){
		long intialTime = System.currentTimeMillis();
		long currentTime = intialTime;
		long maxWaitTime = 5*60*1000;
		
		while (!(js.executeScript("return document.readyState").equals("complete")) && currentTime-intialTime<maxWaitTime) {
			try {
				Thread.sleep(200);
			} catch (Exception e) {
				e.printStackTrace();
			}
			currentTime = System.currentTimeMillis();
		}
	}
	
	protected void waitInSeconds(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	protected void selectByDropDown(By locator, DropDownType type, Object value){
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		Select select = new Select(driver.findElement(locator));
		
		switch(type){
		case BY_INDEX:
			int index = (Integer)value;
			select.selectByIndex(index);
			break;
		case BY_VALUE:
			String val = (String)value;
			select.selectByValue(val);
			break;
		case BY_VISIBLE_TEXT:
			String visibleText = (String)value;
			select.selectByVisibleText(visibleText);
			break;
		}
		
	}
}
