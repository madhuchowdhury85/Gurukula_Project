package gurukulaTest;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.AuthenticationPage;
import pages.BranchPage;
import pages.BranchesPage;
import pages.HomePage;
import pages.LandingPage;
import utils.RandomGeneration;

public class Gurukula_Branch extends BaseTest{

	LandingPage landingPage;
	AuthenticationPage authPage;
	HomePage homePage;
	BranchesPage branchesPage;
	BranchPage branchPage;
	
	@BeforeMethod
	public void login(){
		landingPage = new LandingPage(driver);
		authPage = landingPage.openLoginPage();
		homePage = authPage.login("admin", "admin");
		Assert.assertTrue(homePage.isPageLoaded(), "User is not successfully logged in");
	}
	
	@AfterMethod
	public void logout(){
		landingPage = homePage.logOut();
		Assert.assertTrue(landingPage.isPageLoaded(), "User has not been logged out");
	}
	
	@Test
	public void createBranch(){
		branchesPage = homePage.openBranchesPage();
		String branchName = "Branch" + RandomGeneration.generateRandomString(5);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
	}
	
	
	@Test
	public void createAndSearchBranch(){
		branchesPage = homePage.openBranchesPage();
		String branchName = "Branch" + RandomGeneration.generateRandomString(5);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		
		boolean isBranchFound = branchesPage.searchBranchById(branchId);
		if(isBranchFound){
			log("Successfully found branch with branch id as "+branchId+" after search");
		}else{
			log("Branch branch with branch id as "+branchId+" is not found after search");
		}
		
	}
	
	@Test
	public void createAndViewBranch(){
		branchesPage = homePage.openBranchesPage();
		String branchName = "Branch" + RandomGeneration.generateRandomString(5);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		
		//By Id
		String id = branchId;
		branchPage = branchesPage.viewBranchById(id);
		if(null != branchPage){
			log("Successfully found and opened the branch with id as "+id);
			branchesPage = branchPage.back();
		}else{
			log("Didn't find branch with id as "+id);
		}
		
	}
	
	@Test
	public void createAndEditBranch(){
		branchesPage = homePage.openBranchesPage();
		String branchName = "Branch" + RandomGeneration.generateRandomString(5);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		
		//Edit based on id. Please provide an existing id
		String id = branchId;
		branchName = "Branch" + RandomGeneration.generateRandomString(5);
		branchCode = RandomGeneration.generateRandomNumber(4);
		boolean isBranchFound = branchesPage.editBranchById(id,branchName, String.valueOf(branchCode));
		if(isBranchFound){
			log("Successfully found the branch with id as "+id+" and is being modified");
			log("Branch with branch id "+id +" is modified with new name as "+branchName + " and new code as "+branchCode);
		}else{
			log("Didn't find branch with id as "+id);
		}
		
	}
	
	@Test
	public void createAndDeleteBranch(){
		branchesPage = homePage.openBranchesPage();
		String branchName = "Branch" + RandomGeneration.generateRandomString(5);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		
		//Delete based on id. Please provide an existing id
		String id = branchId;
		log("Deleting branch with id "+id);
		boolean isBranchFound = branchesPage.deleteBranchById(id);
		if(isBranchFound){
			log("Deletion Successful");
		}else{
			log("Deletion failed");
		}
	}
	
	
	//Negative test
	@Test
	public void negativeTest_branchNameEmpty(){
		branchesPage = homePage.openBranchesPage();
		String branchName = "";
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		if(null != branchId){
			log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		}else{
			log("Branch is not created with name as "+branchName + " and branch code as "+branchCode);
			String branchNameErrorMsg = branchesPage.getBranchNameErrorMessage();
			String branchCodeErrorMsg = branchesPage.getBranchCodeErrorMessage();
			if(!"".equals(branchNameErrorMsg)){
				log("Branch Name Error Message : "+branchNameErrorMsg);
			}
			if(!"".equals(branchCodeErrorMsg)){
				log("Branch Code Error Message : "+branchCodeErrorMsg);
			}
		}
		
	}
	//Negative test
	@Test
	public void negativeTest_branchNameWithLessThanMinCharacters(){
		int length = 4;
		log("Creation of branch name with "+length+" characters");
		branchesPage = homePage.openBranchesPage();
		String branchName = RandomGeneration.generateRandomString(length);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		if(null != branchId){
			log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		}else{
			log("Branch is not created with name as "+branchName + " and branch code as "+branchCode);
			String branchNameErrorMsg = branchesPage.getBranchNameErrorMessage();
			String branchCodeErrorMsg = branchesPage.getBranchCodeErrorMessage();
			if(!"".equals(branchNameErrorMsg)){
				log("Branch Name Error Message : "+branchNameErrorMsg);
			}
			if(!"".equals(branchCodeErrorMsg)){
				log("Branch Code Error Message : "+branchCodeErrorMsg);
			}
		}
		
	}
	
	//Negative test
	@Test
	public void negativeTest_branchNameWithMoreThanMaxCharacters(){
		int length = 23;
		log("Creation of branch with "+length+" characters");
		branchesPage = homePage.openBranchesPage();
		String branchName = RandomGeneration.generateRandomString(length);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		if(null != branchId){
			log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		}else{
			log("Branch is not created with name as "+branchName + " and branch code as "+branchCode);
			String branchNameErrorMsg = branchesPage.getBranchNameErrorMessage();
			String branchCodeErrorMsg = branchesPage.getBranchCodeErrorMessage();
			if(!"".equals(branchNameErrorMsg)){
				log("Branch Name Error Message : "+branchNameErrorMsg);
			}
			if(!"".equals(branchCodeErrorMsg)){
				log("Branch Code Error Message : "+branchCodeErrorMsg);
			}
		}
		
	}
	
	//Negative test
	@Test
	public void negativeTest_branchNameInCorrectFormat(){
		branchesPage = homePage.openBranchesPage();
		String branchName = RandomGeneration.generateRandomString(4)+RandomGeneration.generateRandomNumber(4);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		if(null != branchId){
			log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		}else{
			log("Branch is not created with name as "+branchName + " and branch code as "+branchCode);
			String branchNameErrorMsg = branchesPage.getBranchNameErrorMessage();
			String branchCodeErrorMsg = branchesPage.getBranchCodeErrorMessage();
			if(!"".equals(branchNameErrorMsg)){
				log("Branch Name Error Message : "+branchNameErrorMsg);
			}
			if(!"".equals(branchCodeErrorMsg)){
				log("Branch Code Error Message : "+branchCodeErrorMsg);
			}
		}
		
	}
	
	//Negative test
		@Test
		public void negativeTest_branchCodeEmpty(){
			branchesPage = homePage.openBranchesPage();
			String branchName = "Branch" + RandomGeneration.generateRandomString(5);
			String branchCode = "";
			String branchId = branchesPage.createBranch(branchName, branchCode);
			if(null != branchId){
				log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
			}else{
				log("Branch is not created with name as "+branchName + " and branch code as "+branchCode);
				String branchNameErrorMsg = branchesPage.getBranchNameErrorMessage();
				String branchCodeErrorMsg = branchesPage.getBranchCodeErrorMessage();
				if(!"".equals(branchNameErrorMsg)){
					log("Branch Name Error Message : "+branchNameErrorMsg);
				}
				if(!"".equals(branchCodeErrorMsg)){
					log("Branch Code Error Message : "+branchCodeErrorMsg);
				}
			}
			
		}
		//Negative test
		@Test
		public void negativeTest_branchCodeWithLessThanMinCharacters(){
			int length = 1;
			log("Creation of branch code with "+length+" characters");
			branchesPage = homePage.openBranchesPage();
			String branchName = "Branch" + RandomGeneration.generateRandomString(5);
			int branchCode = RandomGeneration.generateRandomNumber(length);
			String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
			if(null != branchId){
				log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
			}else{
				log("Branch is not created with name as "+branchName + " and branch code as "+branchCode);
				String branchNameErrorMsg = branchesPage.getBranchNameErrorMessage();
				String branchCodeErrorMsg = branchesPage.getBranchCodeErrorMessage();
				if(!"".equals(branchNameErrorMsg)){
					log("Branch Name Error Message : "+branchNameErrorMsg);
				}
				if(!"".equals(branchCodeErrorMsg)){
					log("Branch Code Error Message : "+branchCodeErrorMsg);
				}
			}
			
		}
		
		//Negative test
		@Test
		public void negativeTest_branchCodeWithMoreThanMaxCharacters(){
			int length = 12;
			log("Creation of branch with "+length+" characters");
			branchesPage = homePage.openBranchesPage();
			String branchName = "Branch" + RandomGeneration.generateRandomString(5);
			String branchCode = ""+RandomGeneration.generateRandomNumber(length/2)+RandomGeneration.generateRandomNumber(length/2);
			String branchId = branchesPage.createBranch(branchName, branchCode);
			if(null != branchId){
				log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
			}else{
				log("Branch is not created with name as "+branchName + " and branch code as "+branchCode);
				String branchNameErrorMsg = branchesPage.getBranchNameErrorMessage();
				String branchCodeErrorMsg = branchesPage.getBranchCodeErrorMessage();
				if(!"".equals(branchNameErrorMsg)){
					log("Branch Name Error Message : "+branchNameErrorMsg);
				}
				if(!"".equals(branchCodeErrorMsg)){
					log("Branch Code Error Message : "+branchCodeErrorMsg);
				}
			}
			
		}
		
		//Negative test
		@Test
		public void negativeTest_branchCodeInCorrectFormat(){
			branchesPage = homePage.openBranchesPage();
			String branchName = "Branch" + RandomGeneration.generateRandomString(5);
			String branchCode = (RandomGeneration.generateRandomNumber(4)+RandomGeneration.generateRandomString(3)).toLowerCase();
			String branchId = branchesPage.createBranch(branchName, branchCode);
			if(null != branchId){
				log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
			}else{
				log("Branch is not created with name as "+branchName + " and branch code as "+branchCode);
				String branchNameErrorMsg = branchesPage.getBranchNameErrorMessage();
				String branchCodeErrorMsg = branchesPage.getBranchCodeErrorMessage();
				if(!"".equals(branchNameErrorMsg)){
					log("Branch Name Error Message : "+branchNameErrorMsg);
				}
				if(!"".equals(branchCodeErrorMsg)){
					log("Branch Code Error Message : "+branchCodeErrorMsg);
				}
			}
			
		}
	
}
