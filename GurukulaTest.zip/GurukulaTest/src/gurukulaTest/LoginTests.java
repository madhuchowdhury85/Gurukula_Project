package gurukulaTest;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.AuthenticationPage;
import pages.HomePage;
import pages.LandingPage;

public class LoginTests extends BaseTest{
	LandingPage landingPage;
	AuthenticationPage authPage;
	HomePage homePage;
	
	@Test
	public void correctLogin(){
		String userName = "admin";
		String password = "admin";
		
		landingPage = new LandingPage(driver);
		authPage = landingPage.openLoginPage();
		homePage = authPage.login(userName, password);
		if(homePage.isPageLoaded()){
			log("User is logged successfully with username as "+userName+" and password as "+password);
		}
		Assert.assertTrue(homePage.isPageLoaded(), "User is not successfully logged in with correct username as "+userName+" and password as "+password);
		
	}
	
	@Test
	public void incorrectLogin(){
		String userName = "admin";
		String password = "dummypass";
		
		landingPage = new LandingPage(driver);
		authPage = landingPage.openLoginPage();
		homePage = authPage.login(userName, password);
		if(homePage.isPageLoaded()){
			log("User is logged successfully with username as "+userName+" and password as "+password);
		}else{
			log("User is not logged with username as "+userName+" and password as "+password);
		}
		Assert.assertFalse(homePage.isPageLoaded(), "User is logged in with incorrect username as "+userName+" and password as "+password);
		
	}
}
