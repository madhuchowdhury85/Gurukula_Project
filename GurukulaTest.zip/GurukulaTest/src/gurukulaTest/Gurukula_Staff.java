package gurukulaTest;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.AuthenticationPage;
import pages.BranchesPage;
import pages.HomePage;
import pages.LandingPage;
import pages.StaffPage;
import pages.StaffsPage;
import utils.RandomGeneration;

public class Gurukula_Staff extends BaseTest{

	LandingPage landingPage;
	AuthenticationPage authPage;
	HomePage homePage;
	StaffsPage staffsPage;
	StaffPage staffPage;
	BranchesPage branchesPage;
	
	@BeforeMethod
	public void login(){
		landingPage = new LandingPage(driver);
		authPage = landingPage.openLoginPage();
		homePage = authPage.login("admin", "admin");
		Assert.assertTrue(homePage.isPageLoaded(), "User is not successfully logged in");
	}
	
	@AfterMethod
	public void logout(){
		landingPage = homePage.logOut();
		Assert.assertTrue(landingPage.isPageLoaded(), "User has not been logged out");
	}
	
	@Test //(enabled=false)
	public void createStaff(){
		staffsPage = homePage.openStaffsPage();
		String staffName = "Staff" + RandomGeneration.generateRandomString(5);
		String staffId = staffsPage.createStaff(staffName);
		String branchName = staffsPage.getBranchNameById(staffId);
		log("New Staff created with id as "+staffId +", name as "+staffName + " and branch name as "+branchName);
	}
	
	
	@Test //(enabled=false)
	public void createAndSearchStaff(){
		staffsPage = homePage.openStaffsPage();
		String staffName = "Staff" + RandomGeneration.generateRandomString(5);
		String staffId = staffsPage.createStaff(staffName);
		String branchName = staffsPage.getBranchNameById(staffId);
		log("New Staff created with id as "+staffId +", name as "+staffName + " and branch name as "+branchName);
		
		boolean isStaffFound = staffsPage.searchStaffById(staffId);
		if(isStaffFound){
			log("Successfully found branch with branch id as "+staffId+" after search");
		}else{
			log("Branch branch with branch id as "+staffId+" is not found after search");
		}
		
	}
	
	
	@Test //(enabled=false)
	public void createAndViewStaff(){
		staffsPage = homePage.openStaffsPage();
		String staffName = "Staff" + RandomGeneration.generateRandomString(5);
		String staffId = staffsPage.createStaff(staffName);
		String branchName = staffsPage.getBranchNameById(staffId);
		log("New Staff created with id as "+staffId +", name as "+staffName + " and branch name as "+branchName);
		
		//By Id
		String id = staffId;
		staffPage = staffsPage.viewStaffById(id);
		if(null != staffPage){
			log("Successfully found and opened the staff with id as "+id);
			staffsPage = staffPage.back();
		}else{
			log("Didn't find staff with id as "+id);
		}
		
	}
	
	@Test //(enabled=false)
	public void createAndEditStaff(){
		staffsPage = homePage.openStaffsPage();
		String staffName = "Staff" + RandomGeneration.generateRandomString(5);
		String staffId = staffsPage.createStaff(staffName);
		String branchName = staffsPage.getBranchNameById(staffId);
		log("New Staff created with id as "+staffId +", name as "+staffName + " and branch name as "+branchName);
		
		//Edit based on id. Please provide an existing id
		String id = staffId;
		branchesPage = staffsPage.openBranchesPage();
		String newbranchName = "Branch" + RandomGeneration.generateRandomString(5);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(newbranchName, String.valueOf(branchCode));
		Reporter.log("New branch created with id as "+branchId +", name as "+newbranchName + " and branch code as "+branchCode);
		staffsPage = branchesPage.openStaffsPage();
		String newstaffName = "Staff" + RandomGeneration.generateRandomString(5);
		boolean isStaffFound = staffsPage.editStaffById(staffId, newstaffName, newbranchName);
		if(isStaffFound){
			log("Successfully found the staff with id as "+id+" and is being modified");
			log("Staff with staff id "+id +" is modified with new name as "+newstaffName + " and new branch as "+newbranchName);
		}else{
			log("Didn't find branch with id as "+id);
		}
		
	}
	
	@Test //(enabled=false)
	public void createAndDeleteStaff(){
		staffsPage = homePage.openStaffsPage();
		String staffName = "Staff" + RandomGeneration.generateRandomString(5);
		String staffId = staffsPage.createStaff(staffName);
		String branchName = staffsPage.getBranchNameById(staffId);
		log("New Staff created with id as "+staffId +", name as "+staffName + " and branch name as "+branchName);
		
		//Delete based on id. Please provide an existing id
		String id = staffId;
		log("Deleting Staff with id "+id);
		boolean isBranchFound = staffsPage.deleteBranchById(id);
		if(isBranchFound){
			log("Deletion Successful");
		}else{
			log("Deletion failed");
		}
	}
	
	
	//Negative test
	@Test //(enabled=false)
	public void negativeTest_staffNameEmpty(){
		staffsPage = homePage.openStaffsPage();
		String staffName = "";
		String staffId = staffsPage.createStaff(staffName);
		if(null != staffId){
			log("New Staff created with id as "+staffId +", name as "+staffName);
		}else{
			log("Staff is not created with name as empty.");
			String staffNameErrorMsg = staffsPage.getStaffNameErrorMessage();
			if(!"".equals(staffNameErrorMsg)){
				log("Staff Name Error Message : "+staffNameErrorMsg);
			}
		}
	}
		
	//Negative test
	@Test //(enabled=false)
	public void negativeTest_staffNameWithMoreThanMaxCharacters(){
		int length = 52;
		log("Creation of branch with "+length+" characters");
		staffsPage = homePage.openStaffsPage();
		String staffName = RandomGeneration.generateRandomString(length);
		String staffId = staffsPage.createStaff(staffName);
		if(null != staffId){
			log("New Staff created with id as "+staffId +", name as "+staffName);
		}else{
			log("Staff is not created with name as "+staffName);
			String staffNameErrorMsg = staffsPage.getStaffNameErrorMessage();
			if(!"".equals(staffNameErrorMsg)){
				log("Staff Name Error Message : "+staffNameErrorMsg);
			}
		}
	}
	
	
	//Negative test
	@Test //(enabled=true)
	public void negativeTest_staffNameInCorrectFormat(){
		staffsPage = homePage.openStaffsPage();
		String staffName = RandomGeneration.generateRandomString(4)+RandomGeneration.generateRandomNumber(4);;
		String staffId = staffsPage.createStaff(staffName);
		if(null != staffId){
			log("New Staff created with id as "+staffId +", name as "+staffName);
		}else{
			log("Staff is not created with name as "+staffName);
			String staffNameErrorMsg = staffsPage.getStaffNameErrorMessage();
			if(!"".equals(staffNameErrorMsg)){
				log("Staff Name Error Message : "+staffNameErrorMsg);
			}
		}
		
	}
}
