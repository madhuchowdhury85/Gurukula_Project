package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SessionsPage extends BaseLoggedInPage{

	public SessionsPage(WebDriver driver) {
		super(driver);
	}
	By pageHeader = By.xpath("//h2[contains(text(),'Active sessions for')]");

	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
}
