package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PasswordPage extends BaseLoggedInPage{

	public PasswordPage(WebDriver driver) {
		super(driver);
	}
	
	By pageHeader = By.xpath("//h2[contains(text(),'Password for')]");

	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}

}
