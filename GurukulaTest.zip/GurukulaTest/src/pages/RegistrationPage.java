package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegistrationPage extends BaseLoggedOutPage{

	public RegistrationPage(WebDriver driver) {
		super(driver);
	}
	
	By pageHeader = By.xpath("//h1[text()='Registration']");

	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
	

}
