package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AuthenticationPage extends BaseLoggedOutPage{

	public AuthenticationPage(WebDriver driver) {
		super(driver);
	}
	
	By pageHeader = By.xpath("//h1[text()='Authentication']");
	
	By username_txtBox = By.id("username");
	By password_txtBox = By.id("password");
	By automaticLogin_chkBox = By.id("rememberMe");
	By authenticate_btn = By.xpath("//button[text()='Authenticate']");
	
	By forgotPassord_link = By.linkText("Did you forget your password?");
	By register_link = By.linkText("Register a new account");
	

	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
	
	public HomePage login(String userName, String password){
		enterText(username_txtBox, userName);
		enterText(password_txtBox, password);
		clickOn(authenticate_btn);
		return new HomePage(driver);
	}
	
	public ResetPasswordPage forgotPassword(){
		clickOn(forgotPassord_link);
		return new ResetPasswordPage(driver);
	}
	
	public RegistrationPage openRegistrationPage(){
		clickOn(register_link);
		return new RegistrationPage(driver);
	}

	
	
}
