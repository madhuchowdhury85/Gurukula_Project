package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import utils.RandomGeneration;

public class StaffsPage extends BaseLoggedInPage{

	public StaffsPage(WebDriver driver) {
		super(driver);
	}
	
	private static String staffNameErrorMessage = "";
	
	By pageHeader = By.xpath("//h2[text()='Staffs']");
	
	By createStaff_btn = By.xpath("//span[text()='Create a new Staff']");
	By query_txtBox = By.id("searchQuery");
	By search_btn = By.xpath("//span[text()='Search a Staff']");
	
	
	
	By id_txtBox = By.name("id");
	By name_txtBox = By.name("name");
	By branch_dropDown = By.name("related_branch");
	String genericBranchWithName_xpath = "//select[@name='related_branch']/option[text()='<BRANCH_NAME>']";
	String genericBranchWithIndex_xpath = "//select[@name='related_branch']/option[<INDEX>]";
	By staffNameErrMessage_label = By.xpath("//p[contains(@ng-show, 'editForm.name')][not(contains(@class, 'ng-hide'))]");
	
	
	By staffCreationSave_btn = By.xpath("//div[@id='saveStaffModal']//button[@type='submit']");
	By staffCreationCancel_btn = By.xpath("//div[@id='saveStaffModal']//span[text()='Cancel']");
	
	By allStaffRows = By.xpath("//tr[@ng-repeat='staff in staffs' and @class='ng-scope']");
	By lastStaffId_link = By.xpath("(//a[contains(@ui-sref,'staffDetail') and @class='ng-binding'])[last()]");
	
	String generic_viewById_xpath = "//div[@class='table-responsive']//tr[.//a[text()='ID']]//span[text()='View']";
	String generic_editById_xpath = "//div[@class='table-responsive']//tr[.//a[text()='ID']]//span[text()='Edit']";
	String generic_deleteById_xpath = "//div[@class='table-responsive']//tr[.//a[text()='ID']]//span[text()='Delete']";
	
	By deleteStaffDelete_btn = By.xpath("//div[@id='deleteStaffConfirmation']//span[text()='Delete'][not(./ancestor::*[contains(@style,'display: none')])]");
	
	String genericStaffById_xpath = "//tr[@ng-repeat='staff in staffs'][.//a[@class='ng-binding' and text()='<STAFF_ID>']]";
	String genericStaffNameByStaffId_xpath = "//td[./a[@class='ng-binding' and text()='<STAFF_ID>']]/following-sibling::td[2]";
	String genericBranchNameByStaffId_xpath = "//td[./a[@class='ng-binding' and text()='<STAFF_ID>']]/following-sibling::td[1]"; 
	String genericStaffIdByStaffNameOrBranchName_xpath = "//td[@class='ng-binding' and text()='<STAFF_NAME_OR_BRANCH_NAME>']/preceding-sibling::td[not(@class='ng-binding')]/a"; 
	
	By firstPage_btn = By.xpath("//ul[@class='pager']/li[contains(@ng-show,'first')]");
	By previousPage_btn = By.xpath("//ul[@class='pager']/li[contains(@ng-show,'prev')]");
	By nextPage_btn = By.xpath("//ul[@class='pager']/li[contains(@ng-show,'next')]");
	By lastPage_btn = By.xpath("//ul[@class='pager']/li[contains(@ng-show,'last')]");
	
	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
	
	private String findLastCreatedStaffId(){
		clickOn(lastPage_btn);
		return getText(lastStaffId_link);
	}
	
	private boolean checkForBranchDuringStaffCreation(String branchName){
		String branch_xpath = genericBranchWithName_xpath.replace("<BRANCH_NAME>", branchName);
		return verifyElement(By.xpath(branch_xpath), 5);
	}
	
	private String fillAndCreateStaff(String name, String branchName){
		
		if(checkForBranchDuringStaffCreation(branchName))
			selectByDropDown(branch_dropDown, DropDownType.BY_VISIBLE_TEXT, branchName);
		else{
			Reporter.log("Branch with branch name "+branchName+ " is not found in dropdown");
			return null;
		}
		enterText(name_txtBox, name);
		if(checkForEnableElement(staffCreationSave_btn)){
			clickOn(staffCreationSave_btn);
			waitInSeconds(2);
			return findLastCreatedStaffId();
		}else{
			if(verifyElement(staffNameErrMessage_label, 5))
				staffNameErrorMessage = getText(staffNameErrMessage_label);
			clickOn(staffCreationCancel_btn);
			waitInSeconds(1);
		}
		return null;
	}
	
	public String getStaffNameErrorMessage(){
		String errorMsg = staffNameErrorMessage;
		staffNameErrorMessage = "";
		return errorMsg;
	}
	

	public String createStaff(String staffName){
		BranchesPage branchesPage = openBranchesPage();
		String branchName = "Branch" + RandomGeneration.generateRandomString(5);
		int branchCode = RandomGeneration.generateRandomNumber(4);
		String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
		Reporter.log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		openStaffsPage();
		clickOn(createStaff_btn);
		waitInSeconds(1);
		return fillAndCreateStaff(staffName, branchName);
	}
	
	public String createStaff(String staffName, String branchName){
		
		BranchesPage branchesPage = openBranchesPage();
		if(!branchesPage.searchBranchByName(branchName)){
			Reporter.log("Branch with name "+branchName+" is not found. Creating a new branch.", true);
			branchName = "Branch" + RandomGeneration.generateRandomString(5);
			int branchCode = RandomGeneration.generateRandomNumber(4);
			String branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
			Reporter.log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		}
		openStaffsPage();
		clickOn(createStaff_btn);
		waitInSeconds(1);
		return fillAndCreateStaff(staffName, branchName);
	}

	public String createStaffWithBranchId(String staffName, String branchId){
		clickOn(createStaff_btn);
		waitInSeconds(1);
		BranchesPage branchesPage = openBranchesPage();
		String branchName = null;
		if(!branchesPage.searchBranchById(branchId)){
			Reporter.log("Branch with id "+branchId+" is not found. Creating a new branch.", true);
			branchName = "Branch" + RandomGeneration.generateRandomString(5);
			int branchCode = RandomGeneration.generateRandomNumber(4);
			branchId = branchesPage.createBranch(branchName, String.valueOf(branchCode));
			Reporter.log("New branch created with id as "+branchId +", name as "+branchName + " and branch code as "+branchCode);
		}else{
			branchName = branchesPage.getBranchNameById(branchId);
		}
		openStaffsPage();
		clickOn(createStaff_btn);
		waitInSeconds(1);
		return fillAndCreateStaff(staffName, branchName);
	}
	
	public String getBranchNameById(String id){
		String staffNameById = genericStaffNameByStaffId_xpath.replace("<STAFF_ID>", id);
		return getText(By.xpath(staffNameById));
	}
	
	public void clearSearch(){
		clearBox(query_txtBox);
		clickOn(search_btn);
	}
	
	public boolean searchStaffById(String staffId){
		clearSearch();
		boolean isBranchFound = false;
		enterText(query_txtBox, staffId);
		clickOn(search_btn);
		waitInSeconds(1);
		List<WebElement> allRowsEle = driver.findElements(allStaffRows);
		for(WebElement row: allRowsEle){
			waitInSeconds(1);
			String id = row.findElement(By.xpath(".//a[@class='ng-binding']")).getText();
			if(id.equals(staffId)){
				isBranchFound = true;
				break;
			}
		}
		return isBranchFound;
	}
	
	public StaffPage viewStaffById(String staffId){
		if(!findStaffPageWithStaffId(staffId))
			Assert.fail("Staff with staffId "+staffId+ " is not found");
		StaffPage staffPage= null;
		if(verifyElement(By.xpath(generic_viewById_xpath.replace("ID", staffId)))){
			driver.findElement(By.xpath(generic_viewById_xpath.replace("ID", staffId))).click();
			staffPage = new StaffPage(driver);
			waitInSeconds(1);
		}
		return staffPage;
	}
	
	public boolean editStaffById(String staffId, String newName, String newbranch){
		if(!findStaffPageWithStaffId(staffId))
			Assert.fail("Staff with staffId "+staffId+ " is not found");
		boolean isBranchFound = false;
		if(verifyElement(By.xpath(generic_editById_xpath.replace("ID", staffId)))){
			driver.findElement(By.xpath(generic_editById_xpath.replace("ID", staffId))).click();
			waitInSeconds(2);
			if(null != fillAndCreateStaff(newName, newbranch))
				isBranchFound = true;
		}
		return isBranchFound;
	}
	
	public boolean deleteBranchById(String staffId){
		if(!findStaffPageWithStaffId(staffId))
			Assert.fail("Staff with staffId "+staffId+ " is not found");
		boolean isBranchFound = false;
		if(verifyElement(By.xpath(generic_deleteById_xpath.replace("ID", staffId)))){
			driver.findElement(By.xpath(generic_deleteById_xpath.replace("ID", staffId))).click();
			waitInSeconds(3);
			clickOn(deleteStaffDelete_btn);
			waitInSeconds(1);
			if(verifyElement(deleteStaffDelete_btn))
				jsClick(deleteStaffDelete_btn);
			isBranchFound = true;
		}
		return isBranchFound;
	}
	
	public boolean findStaffPageWithStaffId(String staffId){
		clickOn(firstPage_btn);
		do{
			if(verifyElement(By.xpath(genericStaffById_xpath.replace("<STAFF_ID>", staffId)), 5)){
				return true;
			}
			clickOn(nextPage_btn);
		}while(verifyElement(nextPage_btn,5));
		return false;
	}
}
