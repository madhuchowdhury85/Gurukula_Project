package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LandingPage extends BaseLoggedOutPage{

	public LandingPage(WebDriver driver) {
		super(driver);
	}
	
	By pageHeader = By.xpath("//h1[text()='Welcome to Gurukula!']");
	
	By login_link = By.linkText("login");
	By register_link = By.linkText("Register a new account");
	
	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
	
	public AuthenticationPage openLoginPage(){
		waitInSeconds(1);
		clickOn(login_link);
		return new AuthenticationPage(driver);
	}
	
	public RegistrationPage registerAccount(){
		clickOn(register_link);
		return new RegistrationPage(driver);
	}



	
}
