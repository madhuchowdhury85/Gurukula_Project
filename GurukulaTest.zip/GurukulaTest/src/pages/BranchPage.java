package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BranchPage extends BaseLoggedInPage {

	public BranchPage(WebDriver driver) {
		super(driver);
	}
	By pageHeader = By.xpath("//div[@class='container']//span[text()='Branch']");
	By back_button = By.xpath("//span[text()='Back']");
	
	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
	
	public BranchesPage back(){
		clickOn(back_button);
		return new BranchesPage(driver);
	}
	
}
