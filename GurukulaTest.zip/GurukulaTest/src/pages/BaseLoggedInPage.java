package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utils.XpathUtil;

public abstract class BaseLoggedInPage extends BasePage{

	public BaseLoggedInPage(WebDriver driver) {
		super(driver);
	}
	
	By entities_menu = By.xpath(XpathUtil.getNavigationXpath("Entities"));
	By branch_submenu = By.xpath(XpathUtil.getNavigationXpath("Branch"));
	By staff_submenu = By.xpath(XpathUtil.getNavigationXpath("Staff"));
	
	By settings_submenu = By.xpath(XpathUtil.getNavigationXpath("Settings"));
	By password_submenu = By.xpath(XpathUtil.getNavigationXpath("Password"));
	By sessions_submenu = By.xpath(XpathUtil.getNavigationXpath("Sessions"));
	By logOut_submenu = By.xpath(XpathUtil.getNavigationXpath("Log out"));
	
	
	public BranchesPage openBranchesPage(){
		clickOn(entities_menu);
		clickOn(branch_submenu);
		waitInSeconds(1);
		return new BranchesPage(driver);
	}
	
	public StaffsPage openStaffsPage(){
		clickOn(entities_menu);
		clickOn(staff_submenu);
		return new StaffsPage(driver);
	}
	
	public SettingsPage openSettingsPage(){
		clickOn(account_menu);
		clickOn(settings_submenu);
		return new SettingsPage(driver);
	}
	
	public PasswordPage openPasswordPage(){
		clickOn(account_menu);
		clickOn(password_submenu);
		return new PasswordPage(driver);
	}

	public SessionsPage openSessionsPage(){
		clickOn(account_menu);
		clickOn(sessions_submenu);
		return new SessionsPage(driver);
	}
	
	public LandingPage logOut(){
		clickOn(account_menu);
		clickOn(logOut_submenu);
		return new LandingPage(driver);
	}
}
