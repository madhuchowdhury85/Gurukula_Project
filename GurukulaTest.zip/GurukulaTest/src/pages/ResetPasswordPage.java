package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ResetPasswordPage extends BaseLoggedOutPage{

	public ResetPasswordPage(WebDriver driver) {
		super(driver);
	}
	By pageHeader = By.xpath("//h1[text()='Reset your password']");
	
	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
	
	
	
}
