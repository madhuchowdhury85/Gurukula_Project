package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utils.ElementActions;
import utils.XpathUtil;

public abstract class BasePage extends ElementActions{

	public BasePage(WebDriver driver) {
		super(driver);
	}
	
	By home_menu = By.xpath(XpathUtil.getNavigationXpath("Home"));
	By account_menu = By.xpath(XpathUtil.getNavigationXpath("Account"));
	
	public abstract boolean isPageLoaded();

}
