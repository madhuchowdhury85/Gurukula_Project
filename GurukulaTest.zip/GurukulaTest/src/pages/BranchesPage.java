package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BranchesPage extends BaseLoggedInPage{

	public BranchesPage(WebDriver driver) {
		super(driver);
	}

	private static String branchNameErrorMessage = "";
	private static String branchCodeErrorMessage = "";
	
	
	By pageHeader = By.xpath("//h2[text()='Branches']");
	
	By createBranch_btn = By.xpath("//span[text()='Create a new Branch']");
	By query_txtBox = By.id("searchQuery");
	By search_btn = By.xpath("//span[text()='Search a Branch']");
	
	By firstBranchRow = By.xpath("//tr[@ng-repeat='branch in branches' and @class='ng-scope'][1]");
	By allBranchRows = By.xpath("//tr[@ng-repeat='branch in branches' and @class='ng-scope']");
	By lastBranchId_link = By.xpath("//div[@class='table-responsive']//tr[@class='ng-scope'][last()]//a");
	
	By id_txtBox = By.name("id");
	By name_txtBox = By.name("name");
	By code_txtBox = By.name("code");
	By branchNameErrMessage_label = By.xpath("//p[contains(@ng-show, 'editForm.name')][not(contains(@class, 'ng-hide'))]");
	By branchCodeErrMessage_label = By.xpath("//p[contains(@ng-show, 'editForm.code')][not(contains(@class, 'ng-hide'))]");
	By branchCreationSave_btn = By.xpath("//div[@id='saveBranchModal']//button[@type='submit']");
	By branchCreationCancel_btn = By.xpath("//form[@name='editForm']//span[text()='Cancel']");
	
	By deleteBranchDelete_btn = By.xpath("//div[@id='deleteBranchConfirmation']//span[text()='Delete'][not(./ancestor::*[contains(@style,'display: none')])]");
	////form[@name='deleteForm']//span[text()='Delete']
	
	String generic_view_xpath = "//div[@class='table-responsive']//tr[./td[text()='NAME_OR_CODE']]//span[text()='View']";
	String generic_edit_xpath = "//div[@class='table-responsive']//tr[./td[text()='NAME_OR_CODE']]//span[text()='Edit']";
	String generic_delete_xpath = "//div[@class='table-responsive']//tr[./td[text()='NAME_OR_CODE']]//span[text()='Delete']";
	
	String generic_viewById_xpath = "//div[@class='table-responsive']//tr[.//a[text()='ID']]//span[text()='View']";
	String generic_editById_xpath = "//div[@class='table-responsive']//tr[.//a[text()='ID']]//span[text()='Edit']";
	String generic_deleteById_xpath = "//div[@class='table-responsive']//tr[.//a[text()='ID']]//span[text()='Delete']";
	
	By firstRow_view_btn = By.xpath("//div[@class='table-responsive']//tr[1][@class='ng-scope']//span[text()='View']");
	By firstRow_edit_btn = By.xpath("//div[@class='table-responsive']//tr[1][@class='ng-scope']//span[text()='Edit']");
	By firstRow_delete_btn = By.xpath("//div[@class='table-responsive']//tr[1][@class='ng-scope']//span[text()='Delete']");
	
	String genericBranchNameById_xpath = "//td[./a[@class='ng-binding' and text()='<BRANCH_ID>']]/following-sibling::td[1]";
	String genericBranchCodeById_xpath = "//td[./a[@class='ng-binding' and text()='<BRANCH_ID>']]/following-sibling::td[2]"; 
	String genericBranchIdByNameOrCode_xpath = "//td[@class='ng-binding' and text()='<BRANCH_NAME_OR_CODE>']/preceding-sibling::td[not(@class='ng-binding')]/a"; 
	
	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
	
	public boolean searchBranchByName(String branchName){
		clearSearch();
		boolean isBranchFound = false;
		enterText(query_txtBox, branchName);
		clickOn(search_btn);
		List<WebElement> allRowsEle = driver.findElements(allBranchRows);
		for(WebElement row: allRowsEle){
			String name = row.findElement(By.xpath("./td[@class='ng-binding'][1]")).getText();
			if(name.equals(branchName)){
				isBranchFound = true;
				break;
			}
		}
		return isBranchFound;
	}
	
	public boolean searchBranchByCode(String branchCode){
		clearSearch();
		boolean isBranchFound = false;
		enterText(query_txtBox, branchCode);
		clickOn(search_btn);
		List<WebElement> allRowsEle = driver.findElements(allBranchRows);
		for(WebElement row: allRowsEle){
			String code = row.findElement(By.xpath("./td[@class='ng-binding'][2]")).getText();
			if(code.equals(branchCode)){
				isBranchFound = true;
				break;
			}
		}
		return isBranchFound;
	}
	
	public boolean searchBranchById(String branchId){
		clearSearch();
		boolean isBranchFound = false;
		enterText(query_txtBox, branchId);
		clickOn(search_btn);
		waitInSeconds(1);
		List<WebElement> allRowsEle = driver.findElements(allBranchRows);
		for(WebElement row: allRowsEle){
			waitInSeconds(1);
			String id = row.findElement(By.xpath(".//a[@class='ng-binding']")).getText();
			if(id.equals(branchId)){
				isBranchFound = true;
				break;
			}
		}
		return isBranchFound;
	}
	
	public void clearSearch(){
		clearBox(query_txtBox);
		clickOn(search_btn);
	}
	
	private String fillAndCreateBranch(String name, String code){
		enterText(name_txtBox, name);
		enterText(code_txtBox, code);
		if(checkForEnableElement(branchCreationSave_btn)){
			clickOn(branchCreationSave_btn);
			waitInSeconds(2);
			return getText(lastBranchId_link);
		}else{
			if(verifyElement(branchNameErrMessage_label, 5))
				branchNameErrorMessage = getText(branchNameErrMessage_label);
			if(verifyElement(branchCodeErrMessage_label, 5))
				branchCodeErrorMessage = getText(branchCodeErrMessage_label);
			clickOn(branchCreationCancel_btn);
			waitInSeconds(1);
		}
		return null;
	}
	
	public String getBranchNameErrorMessage(){
		String errorMsg = branchNameErrorMessage;
		branchNameErrorMessage = "";
		return errorMsg;
	}
	
	public String getBranchCodeErrorMessage(){
		String errorMsg = branchCodeErrorMessage;
		branchCodeErrorMessage = "";
		return errorMsg;
	}
	
	public String createBranch(String name, String code){
		clickOn(createBranch_btn);
		waitInSeconds(1);
		return fillAndCreateBranch(name, code);
	}
	
	public BranchPage viewBranchByNameOrCode(String nameOrCode){
		BranchPage branchPage= null;
		if(verifyElement(By.xpath(generic_view_xpath.replace("NAME_OR_CODE", nameOrCode)))){
			driver.findElement(By.xpath(generic_view_xpath.replace("NAME_OR_CODE", nameOrCode))).click();
			branchPage = new BranchPage(driver);
			waitInSeconds(1);
		}
		return branchPage;
	}
	
	public boolean editBranchByNameOrCode(String nameOrCode, String newName, String newCode){
		boolean isBranchFound = false;
		if(verifyElement(By.xpath(generic_edit_xpath.replace("NAME_OR_CODE", nameOrCode)))){
			driver.findElement(By.xpath(generic_edit_xpath.replace("NAME_OR_CODE", nameOrCode))).click();
			waitInSeconds(2);
			enterText(name_txtBox, newName);
			enterText(code_txtBox, newCode);
			clickOn(branchCreationSave_btn);
			isBranchFound = true;
		}
		return isBranchFound;
	}
	
	
		
	public boolean deleteBranchByNameOrCode(String nameOrCode){
		boolean isBranchFound = false;
		if(verifyElement(By.xpath(generic_delete_xpath.replace("NAME_OR_CODE", nameOrCode)))){
			driver.findElement(By.xpath(generic_delete_xpath.replace("NAME_OR_CODE", nameOrCode))).click();
			waitInSeconds(3);
			clickOn(deleteBranchDelete_btn);
			waitInSeconds(1);
			if(verifyElement(deleteBranchDelete_btn))
				jsClick(deleteBranchDelete_btn);
			isBranchFound = true;
		}
		return isBranchFound;
	}
	
	public BranchPage viewBranchById(String id){
		BranchPage branchPage= null;
		if(verifyElement(By.xpath(generic_viewById_xpath.replace("ID", id)))){
			driver.findElement(By.xpath(generic_viewById_xpath.replace("ID", id))).click();
			branchPage = new BranchPage(driver);
			waitInSeconds(1);
		}
		return branchPage;
	}

	public boolean editBranchById(String id, String newName, String newCode){
		boolean isBranchFound = false;
		if(verifyElement(By.xpath(generic_editById_xpath.replace("ID", id)))){
			driver.findElement(By.xpath(generic_editById_xpath.replace("ID", id))).click();
			waitInSeconds(2);
			enterText(name_txtBox, newName);
			enterText(code_txtBox, newCode);
			clickOn(branchCreationSave_btn);
			isBranchFound = true;
		}
		return isBranchFound;
	}
	
	public boolean deleteBranchById(String id){
		boolean isBranchFound = false;
		if(verifyElement(By.xpath(generic_deleteById_xpath.replace("ID", id)))){
			driver.findElement(By.xpath(generic_deleteById_xpath.replace("ID", id))).click();
			waitInSeconds(3);
			clickOn(deleteBranchDelete_btn);
			waitInSeconds(1);
			if(verifyElement(deleteBranchDelete_btn))
				jsClick(deleteBranchDelete_btn);
			isBranchFound = true;
		}
		return isBranchFound;
	}
	
	public BranchPage viewFirstVisibleBranch(){
		BranchPage branchPage= null;
		if(verifyElement(firstBranchRow)){
			clickOn(firstRow_view_btn);
			branchPage = new BranchPage(driver);
			waitInSeconds(1);
		}
		return branchPage;
	}
	
	public boolean editFirstVisibleBranch(String newName, String newCode){
		boolean isBranchFound=false;
		if(verifyElement(firstBranchRow)){
			clickOn(firstRow_edit_btn);
			waitInSeconds(2);
			enterText(name_txtBox, newName);
			enterText(code_txtBox, newCode);
			clickOn(branchCreationSave_btn);
			isBranchFound = true;
		}
		return isBranchFound;
	}
	
	public boolean deleteFirstVisibleBranch(){
		boolean isBranchFound=false;
		if(verifyElement(firstBranchRow)){
			clickOn(firstRow_delete_btn);
			waitInSeconds(3);
			clickOn(deleteBranchDelete_btn);
			waitInSeconds(1);
			if(verifyElement(deleteBranchDelete_btn))
				jsClick(deleteBranchDelete_btn);
			isBranchFound = true;
		}
		return isBranchFound;
	}
	
	public String getBranchNameById(String id){
		if(searchBranchById(id)){
			String branchNameById = genericBranchNameById_xpath.replace("<BRANCH_ID>", id);
			return getText(By.xpath(branchNameById));
		}else{
			return null;
		}
	}
	
	public String getBranchCodeById(String id){
		if(searchBranchById(id)){
			String branchCodeById = genericBranchCodeById_xpath.replace("<BRANCH_ID>", id);
			return getText(By.xpath(branchCodeById));
		}else{
			return null;
		}
	}
	
	public String getBranchIdByName(String branchName){
		if(searchBranchByName(branchName)){
			String branchIdByName = genericBranchIdByNameOrCode_xpath.replace("<BRANCH_NAME_OR_CODE>", branchName);
			return getText(By.xpath(branchIdByName));
		}else{
			return null;
		}
	}
	
	public String getBranchIdByCode(String branchCode){
		if(searchBranchByCode(branchCode)){
			String branchIdByCode = genericBranchIdByNameOrCode_xpath.replace("<BRANCH_NAME_OR_CODE>", branchCode);
			return getText(By.xpath(branchIdByCode));
		}else{
			return null;
		}
	}

}
