package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class StaffPage extends BaseLoggedInPage{

	public StaffPage(WebDriver driver) {
		super(driver);
	}
	By pageHeader = By.xpath("//div[@class='container']//span[text()='Staff']");
	By back_button = By.xpath("//span[text()='Back']");
	
	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}
	
	public StaffsPage back(){
		clickOn(back_button);
		return new StaffsPage(driver);
	}

}
