package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utils.XpathUtil;

public abstract class BaseLoggedOutPage extends BasePage{

	public BaseLoggedOutPage(WebDriver driver) {
		super(driver);
	}
	
	By authenticate_submenu = By.xpath(XpathUtil.getNavigationXpath("Authenticate"));
	By register_submenu = By.xpath(XpathUtil.getNavigationXpath("Register"));
	
	public AuthenticationPage openLoginPage(){
		clickOn(account_menu);
		clickOn(authenticate_submenu);
		return new AuthenticationPage(driver);
	}
	
	public RegistrationPage registerAccount(){
		clickOn(account_menu);
		clickOn(register_submenu);
		return new RegistrationPage(driver);
	}

}
