package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SettingsPage extends BaseLoggedInPage{

	public SettingsPage(WebDriver driver) {
		super(driver);
	}
	By pageHeader = By.xpath("//h2[contains(text(),'User settings for')]");

	@Override
	public boolean isPageLoaded() {
		return verifyElement(pageHeader);
	}

}
