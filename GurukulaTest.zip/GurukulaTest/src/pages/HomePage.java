package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BaseLoggedInPage{
	
	public HomePage(WebDriver driver) {
		super(driver);
	}
	
	By pageHeader = By.xpath("//h1[text()='Welcome to Gurukula!']");
	By successLoginMessage_label = By.xpath("//div[contains(@class,'alert-success') and contains(text(),'You are logged in as user')]");
	
	@Override
	public boolean isPageLoaded() {
		return (verifyElement(pageHeader) && verifyElement(successLoginMessage_label));
	}
	

}
